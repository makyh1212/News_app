import { NewsArticlesService } from '../api/news-articles.service';
import { Component } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';

interface Article {
  // definujte vlastnosti, které očekáváte v článku
  title: string;
  // další vlastnosti...
}

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  selectedCategory = "health"
  topHeadlines: any[] = []

  constructor(private articleService: NewsArticlesService, private router: Router) {
    articleService.getTopHeadlines().subscribe((results) => {
      this.topHeadlines.push(...results.articles)
      console.log(this.topHeadlines);
    })


    articleService.getArticleByCategory(this.selectedCategory).subscribe((results) => {
      console.log(results);
    })

  }

  getDetails(selectedArticle: any) {                  //přidala jsem any - jinak svítí :(
    // console.log(selectedArticle)
    const params: NavigationExtras = {
      queryParams: {
        'author': selectedArticle.author,
        'content': selectedArticle.content,
        'description': selectedArticle.description,
        'publishedAt': selectedArticle.publishedAt,
        'source': selectedArticle.source.name,
        'title': selectedArticle.title,
        'url': selectedArticle.url,
        'urlToImage': selectedArticle.urlToImage,
      }
    }
    this.router.navigate(['/details'], params)
  }

}
